<?php // phpcs:disable WebimpressCodingStandard.NamingConventions.Interface.Suffix


declare(strict_types=1);

namespace Laminas\Stdlib;

/**
 * @deprecated Since 3.1.0; use the native JsonSerializable interface
 */
interface JsonSerializable extends \JsonSerializable
{
}
