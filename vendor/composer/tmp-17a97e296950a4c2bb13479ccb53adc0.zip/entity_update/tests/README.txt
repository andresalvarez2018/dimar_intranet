
PHPUnit Tests
-------------
vendor/bin/phpunit modules/contrib/entity_update/tests/src/Functional/InstallUninstallTest.php
vendor/bin/phpunit modules/contrib/entity_update/tests/src/Functional/EntityUpdateFunctionsTest.php
vendor/bin/phpunit modules/contrib/entity_update/tests/src/Functional/EntityUpdateUIAccessTest.php
vendor/bin/phpunit modules/contrib/entity_update/tests/src/Functional/EntityUpdateProgUpTest.php
vendor/bin/phpunit modules/contrib/entity_update/tests/src/Functional/EntityUpdateUIFunctionsTest.php
