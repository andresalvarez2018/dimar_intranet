<?php

declare(strict_types = 1);

namespace Drupal\ldap_user\Exception;

/**
 * Bad parameters exception handling.
 */
class LdapBadParamsException extends \Exception {
  // @todo Use this.
}
