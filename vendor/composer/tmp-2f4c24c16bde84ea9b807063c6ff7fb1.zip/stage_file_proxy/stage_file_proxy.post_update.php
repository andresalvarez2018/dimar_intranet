<?php

/**
 * @file
 * Post update functions for Stage File Proxy.
 */

/**
 * Move Drush commands to drush folder for 12.
 */
function stage_file_proxy_post_update_move_drush_folder(): void {
  // Empty update hook to clear cache.
}
