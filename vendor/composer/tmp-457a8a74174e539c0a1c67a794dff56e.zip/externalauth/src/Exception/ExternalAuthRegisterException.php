<?php

namespace Drupal\externalauth\Exception;

/**
 * Class ExternalAuthRegisterException.
 */
class ExternalAuthRegisterException extends \Exception {}
