((Drupal) => {
  Drupal.behaviors.webformUiElementsToggleWeight = {};
})(Drupal);
