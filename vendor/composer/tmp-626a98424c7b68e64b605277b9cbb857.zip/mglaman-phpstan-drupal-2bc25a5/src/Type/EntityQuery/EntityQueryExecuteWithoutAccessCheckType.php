<?php

declare(strict_types=1);

namespace mglaman\PHPStanDrupal\Type\EntityQuery;

use PHPStan\Type\ArrayType;

final class EntityQueryExecuteWithoutAccessCheckType extends ArrayType
{

}
