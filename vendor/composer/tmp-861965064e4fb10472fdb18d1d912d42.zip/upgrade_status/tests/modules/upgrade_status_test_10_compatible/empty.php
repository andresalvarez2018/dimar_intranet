<?php
/**
 * @file Included to make PHPStan satisfied that it scanned something.
 */
