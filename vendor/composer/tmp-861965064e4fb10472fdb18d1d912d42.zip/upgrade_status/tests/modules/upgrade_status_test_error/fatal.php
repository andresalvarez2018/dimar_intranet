<?php

Fatal error
