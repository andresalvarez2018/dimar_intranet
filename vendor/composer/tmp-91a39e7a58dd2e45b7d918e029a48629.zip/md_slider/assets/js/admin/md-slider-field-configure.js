/**
 * @file
 * AJAX commands used by Editor module.
 */

(function ($, Drupal) {
    'use strict';
    Drupal.behaviors.MDSliderImage = {
        attach: function (context, settings) {

        },
    };

})(jQuery, Drupal);
