<?php

declare(strict_types=1);

namespace Laminas\Text\Figlet\Exception;

use Laminas\Text\Exception\ExceptionInterface as Exception;

interface ExceptionInterface extends Exception
{
}
